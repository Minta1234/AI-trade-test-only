import numpy as np
import pandas as pd
import joblib
import os

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier

from minta_trader.data_loader import CSVLoader
from minta_trader.indicators import add_indicators
from minta_trader.utils import load_json


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(models_dir, exist_ok=True)

    config_path = os.path.join(base_dir, "config", "config.json")
    config = load_json(config_path)

    csv_path = os.path.join(base_dir, config["csv_path"])

    print(f"[TRAIN AI] Load data from {csv_path}")
    loader = CSVLoader(csv_path)
    df = loader.load()
    df = add_indicators(df)

    # ===============================
    # 7 FEATURES (EMA + RSI + MACD)
    # ===============================
    feature_cols = [
        "return_1", 
        "ema_fast", "ema_slow", "rsi",
        "macd", "macd_signal", "macd_hist"
    ]

    # Extract X matrix
    X = df[feature_cols].values

    # Target: close increase?
    future_close = df["close"].shift(-1)
    y = (future_close > df["close"]).astype(int)

    # Remove last NaN row
    X = X[:-1]
    y = y[:-1]

    # ===============================
    # Train/Test Split
    # ===============================
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # ===============================
    # Model
    # ===============================
    model = MLPClassifier(hidden_layer_sizes=(32, 16), max_iter=500)
    model.fit(X_train_scaled, y_train)

    score = model.score(X_test_scaled, y_test)
    print(f"[TRAIN AI] Test accuracy: {score:.4f}")

    # ===============================
    # Save Model
    # ===============================
    model_path = os.path.join(models_dir, "ai_model.pkl")
    scaler_path = os.path.join(models_dir, "scaler.pkl")

    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)

    print(f"[TRAIN AI] Saved {model_path}")
    print(f"[TRAIN AI] Saved {scaler_path}")


if __name__ == "__main__":
    main()
