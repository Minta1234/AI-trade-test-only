
# Minta AI Trader – Forex 5m (Full v2, Real Chart Ready)

ระบบเทรด Forex ด้วย Python ที่มีทั้ง:
- Backtest (Rule-based + AI)
- Train AI Model
- Real-time Chart Dashboard (ดึงกราฟจริงจาก Internet)
- Paper Trading Executor (จำลองการเทรด)

## ฟีเจอร์

- ใช้ข้อมูล Forex 5m จากไฟล์ CSV สำหรับ Backtest
- AI Model แบบ MLPClassifier ทำนายทิศทางแท่งถัดไป
- Rule Strategy แบบ EMA(9)/EMA(21) + RSI(14)
- Risk Management แบบ fixed % ต่อไม้
- Real-time Chart ด้วย Streamlit + yfinance (กราฟจริง 5m)
- Paper Trading Executor (บันทึกดีลลง logs/trades.csv)

## โครงสร้างโปรเจกต์

```text
minta_ai_trader_full_v2/
├─ data/
│  ├─ raw/
│  │  └─ EURUSD_5m_sample.csv
│  └─ processed/
├─ models/
│  ├─ ai_model.pkl      (หลังเทรน)
│  └─ scaler.pkl        (หลังเทรน)
├─ logs/
│  └─ trades.csv        (หลังเทรดจำลอง)
├─ config/
│  └─ config.json
├─ minta_trader/
│  ├─ __init__.py
│  ├─ data_loader.py
│  ├─ indicators.py
│  ├─ strategy_rule.py
│  ├─ strategy_ai.py
│  ├─ risk.py
│  ├─ backtester.py
│  ├─ executor.py
│  └─ utils.py
├─ train_ai.py
├─ run_backtest.py
├─ streamlit_app.py
└─ requirements.txt
```

## การติดตั้ง (Windows)

1. แตก ZIP เช่นไปที่ `D:\minta_ai_trader_full_v2`
2. เปิด PowerShell หรือ CMD แล้ว cd เข้าไปโฟลเดอร์นั้น
3. ติดตั้ง dependencies:

```bash
pip install -r requirements.txt
```

## การใช้งาน Backtest

1. แก้ `config/config.json`:

```json
{
  "mode": "rule",
  "initial_balance": 1000.0,
  "risk_per_trade": 0.01,
  "symbol": "EURUSD",
  "timeframe": "5m",
  "csv_path": "data/raw/EURUSD_5m_sample.csv"
}
```

- mode = "rule"  ใช้ EMA+RSI
- mode = "ai"    ใช้ AI Model

2. ถ้าใช้โหมด AI ต้องเทรนก่อน:

```bash
python train_ai.py
```

3. รัน Backtest:

```bash
python run_backtest.py
```

## การใช้งาน Real-time Chart (กราฟจริง)

1. ตรวจสอบ `config/config.json` ให้ symbol ตรง เช่น "EURUSD"
2. รัน Streamlit:

```bash
streamlit run streamlit_app.py
```

3. จะเปิด browser แสดงกราฟจริง (ดึงจาก Yahoo Finance ผ่าน yfinance) timeframe 5m
   - เลือกใช้โหมด Rule หรือ AI จาก config.json (เหมือนตอน Backtest)
   - ระบบจะ:
     - ดึงกราฟ 5m ล่าสุด
     - คำนวณอินดิเคเตอร์
     - แสดงสัญญาณ BUY/SELL ล่าสุด
     - (Optional) สามารถต่อกับ executor เพื่อทำ paper trading ได้

## คำเตือน

- ระบบนี้เป็น **paper trading / research framework** ไม่ใช่คำแนะนำการลงทุน
- ถ้าจะต่อกับ Broker เพื่อเทรดเงินจริง ต้องตรวจสอบความถูกต้องเองทั้งหมด
