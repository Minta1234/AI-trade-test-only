
import os
from minta_trader.data_loader import CSVLoader
from minta_trader.indicators import add_indicators
from minta_trader.backtester import Backtester
from minta_trader.utils import load_json


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base_dir, "config", "config.json")
    config = load_json(config_path)

    csv_path = os.path.join(base_dir, config["csv_path"])
    mode = config.get("mode", "rule")
    initial_balance = config.get("initial_balance", 1000.0)
    risk_per_trade = config.get("risk_per_trade", 0.01)

    print("[BACKTEST] Mode:", mode)
    print("[BACKTEST] Load data from:", csv_path)

    loader = CSVLoader(csv_path)
    df = loader.load()
    df = add_indicators(df)

    bt = Backtester(
        df,
        base_dir=base_dir,
        mode=mode,
        initial_balance=initial_balance,
        risk_per_trade=risk_per_trade,
    )
    result = bt.run()

    print("==============================")
    print("Symbol:", config.get("symbol"))
    print("Timeframe:", config.get("timeframe"))
    print("Mode:", result["mode"])
    print("Initial balance:", result["initial_balance"])
    print("Final balance:", result["final_balance"])
    print("PnL:", result["pnl"])
    print("Total bars:", len(df))
    print("==============================")


if __name__ == "__main__":
    main()
