import pandas as pd
import numpy as np
import joblib
import chardet
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator
from ta.trend import MACD

MODEL_PATH = "models/ai_model.pkl"
SCALER_PATH = "models/scaler.pkl"

# -------------------------------------------------------
# โหลดโมเดล + scaler
# -------------------------------------------------------
model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

# -------------------------------------------------------
# โหลด CSV (รองรับ UTF-16, UTF-8, SHIFT-JIS)
# -------------------------------------------------------
def load_new_csv(path):
    # detect encoding
    with open(path, "rb") as f:
        raw = f.read()
        enc = chardet.detect(raw)["encoding"]

    print("[Detect Encoding]", enc)

    df = pd.read_csv(path, encoding=enc)

    # strip spaces in header
    df.columns = df.columns.str.strip()

    # detect datetime column
    dt_candidates = ["datetime", "Date", "time"]

    dt_col = None
    for c in dt_candidates:
        if c in df.columns:
            dt_col = c
            break

    if dt_col is None:
        raise ValueError(f"No datetime column found. Columns = {df.columns}")

    df[dt_col] = pd.to_datetime(df[dt_col])
    df.set_index(dt_col, inplace=True)

    return df

# -------------------------------------------------------
# ฟังก์ชันเพิ่มอินดิเคเตอร์ เหมือนตอน train
# -------------------------------------------------------
def add_indicators(df):
    close = df["close"]

    df["ema_fast"] = EMAIndicator(close=close, window=9).ema_indicator()
    df["ema_slow"] = EMAIndicator(close=close, window=21).ema_indicator()

    df["rsi"] = RSIIndicator(close=close, window=14).rsi()

    macd = MACD(close=close)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_hist"] = macd.macd_diff()

    df["return_1"] = close.pct_change()

    df = df.replace([np.inf, -np.inf], np.nan).ffill().bfill()
    return df

# -------------------------------------------------------
# Predict
# -------------------------------------------------------
def predict_signal(csv_path):
    df = load_new_csv(csv_path)
    df = add_indicators(df)

    features = [
        "ema_fast","ema_slow","rsi",
        "macd","macd_signal","macd_hist","return_1"
    ]

    X = df[features].values
    X_scaled = scaler.transform(X)

    preds = model.predict(X_scaled)
    df["prediction"] = preds
    return df

# ===========================
# RUN TEST
# ===========================
if __name__ == "__main__":
    result = predict_signal("data/raw/EURUSD_5m_sample.csv")
    print(result.tail())
