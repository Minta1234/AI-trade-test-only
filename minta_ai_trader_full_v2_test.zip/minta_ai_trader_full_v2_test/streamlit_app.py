import os
from datetime import datetime, timedelta

import pandas as pd
import yfinance as yf
import streamlit as st
import plotly.graph_objects as go

from minta_trader.indicators import add_indicators
from minta_trader.strategy_rule import RuleStrategy
from minta_trader.strategy_ai import AIStrategy
from minta_trader.utils import load_json


def symbol_to_yahoo(symbol: str) -> str:
    """
    Map Forex symbol เช่น EURUSD -> EURUSD=X สำหรับ Yahoo Finance
    """
    suffix = "=X"
    if symbol.endswith(suffix):
        return symbol
    return symbol + suffix


def load_realtime_data(
    symbol: str,
    interval: str = "5m",
    lookback_hours: int = 24
) -> pd.DataFrame:
    """
    ดึงข้อมูลจาก yfinance แล้วรีเนมคอลัมน์เป็นตัวพิมพ์เล็ก:
    open, high, low, close, volume
    """
    yahoo_symbol = symbol_to_yahoo(symbol)

    period = "1d"
    if lookback_hours > 24:
        period = "5d"

    df = yf.download(
        tickers=yahoo_symbol,
        period=period,
        interval=interval,
    )

    if df is None or df.empty:
        return pd.DataFrame()

    df = df.rename(columns={
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
    })

    df.index.name = "datetime"
    return df


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base_dir, "config", "config.json")
    config = load_json(config_path)

    st.title("Minta AI Trader – Real-time Chart (Forex 5m)")

    mode = config.get("mode", "ai")          # "ai" หรือ "rule"
    symbol = config.get("symbol", "EURUSD")
    timeframe = config.get("timeframe", "5m")

    st.sidebar.header("Config")
    st.sidebar.write(f"Mode: **{mode}**")
    st.sidebar.write(f"Symbol: **{symbol}**")
    st.sidebar.write(f"Timeframe: **{timeframe}**")

    st.markdown("**โหลดกราฟจริงจาก Yahoo Finance (yfinance)**")

    # -----------------------------
    # Load Data
    # -----------------------------
    try:
        df = load_realtime_data(symbol, interval="5m", lookback_hours=24)
    except Exception as e:
        st.error(f"Download error: {e}")
        st.stop()

    if df is None or df.empty:
        st.error("No data from Yahoo Finance (df empty).")
        st.stop()

    if len(df) < 30:
        st.error("ข้อมูลน้อยเกินไป (<30 bars)")
        st.stop()

    # กัน NaN ที่มากเกิน
    df = df.dropna()
    if df.empty:
        st.error("ข้อมูลมี NaN มากเกินไปหลัง dropna()")
        st.stop()

    # -----------------------------
    # Add Indicators
    # -----------------------------
    try:
        df = add_indicators(df)
    except KeyError as e:
        st.error(f"Error adding indicators (missing column): {e}")
        st.write("Columns in df:", list(df.columns))
        st.stop()
    except Exception as e:
        st.error(f"Error adding indicators: {e}")
        st.stop()

    # -----------------------------
    # Load Strategy
    # -----------------------------
    if mode == "rule":
        strategy = RuleStrategy()
    else:
        try:
            strategy = AIStrategy(base_dir=base_dir)
        except FileNotFoundError as e:
            st.error(f"โหลดโมเดล AI ไม่ได้: {e}")
            st.info("ให้รัน `python train_ai.py` ก่อน แล้วค่อยเปิดหน้านี้")
            return
        except Exception as e:
            st.error(f"Error initialising AIStrategy: {e}")
            return

    # -----------------------------
    # Generate signals
    # -----------------------------
    signals = []
    for _, row in df.iterrows():
        sig = strategy.generate_signal(row)
        signals.append(sig)

    df["signal"] = signals

    # -----------------------------
    # Plot Chart + Signals
    # -----------------------------
    fig = go.Figure()

    # Candle
    fig.add_trace(go.Candlestick(
        x=df.index,
        open=df["open"],
        high=df["high"],
        low=df["low"],
        close=df["close"],
        name="Price"
    ))

    # BUY markers
    buy = df[df["signal"] == "BUY"]
    fig.add_trace(go.Scatter(
        x=buy.index,
        y=buy["close"],
        mode="markers",
        name="BUY",
        marker_symbol="triangle-up",
        marker_size=9,
        marker_color="green",
    ))

    # SELL markers
    sell = df[df["signal"] == "SELL"]
    fig.add_trace(go.Scatter(
        x=sell.index,
        y=sell["close"],
        mode="markers",
        name="SELL",
        marker_symbol="triangle-down",
        marker_size=9,
        marker_color="red",
    ))

    fig.update_layout(
        xaxis_rangeslider_visible=False,
        title=f"{symbol} 5m – Real-time Chart with Signals ({mode.upper()})",
    )

    st.plotly_chart(fig, use_container_width=True)

    # -----------------------------
    # Show latest bar
    # -----------------------------
    latest = df.iloc[-1]
    st.subheader("Latest Bar & Signal")
    st.write(f"Time: {latest.name}")
    st.write(f"Close: {latest['close']:.5f}")
    st.write(f"Signal: **{latest['signal']}**")


if __name__ == "__main__":
    main()
