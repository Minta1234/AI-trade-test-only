def load_new_csv(path):
    import chardet
    import pandas as pd

    # detect encoding
    with open(path, "rb") as f:
        raw = f.read()
        enc = chardet.detect(raw)["encoding"]

    print("[Detect Encoding]", enc)

    # MT5 CSV = UTF-16 + TAB-separated
    df = pd.read_csv(
        path,
        encoding=enc,
        sep="\t",        # ← สำคัญมาก
        engine="python"
    )

    # strip header
    df.columns = df.columns.str.strip()

    # ต้องมีคอลัมน์ Date + Time แบบ MT5
    if not {"Date", "Time"}.issubset(df.columns):
        raise ValueError(f"MT5 CSV must contain Date + Time columns. Found: {df.columns}")

    # รวม datetime
    df["datetime"] = pd.to_datetime(
        df["Date"].astype(str) + " " + df["Time"].astype(str),
        errors="coerce"
    )
    df = df.dropna(subset=["datetime"])
    df = df.set_index("datetime")

    # rename columns ให้ตรงกับระบบ
    df = df.rename(columns={
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume"
    })

    # convert numeric
    for col in ["open","high","low","close","volume"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna()

    return df
