
class RiskManager:
    """
    จัดการความเสี่ยงแบบง่าย: เสี่ยงเป็น % ของพอร์ตต่อไม้
    """

    def __init__(self, balance: float, risk_per_trade: float = 0.01):
        self.balance = balance
        self.risk_per_trade = risk_per_trade

    def update_balance(self, new_balance: float):
        self.balance = new_balance

    def position_size(self, entry_price: float, stop_loss_price: float) -> float:
        risk_amount = self.balance * self.risk_per_trade
        stop_distance = abs(entry_price - stop_loss_price)
        if stop_distance <= 0:
            return 0.0
        size = risk_amount / stop_distance
        return size
