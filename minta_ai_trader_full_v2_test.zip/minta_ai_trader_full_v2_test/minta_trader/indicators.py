import pandas as pd
import numpy as np
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator
from ta.trend import MACD


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    if "close" not in df.columns:
        raise KeyError(f"'close' column not found. Columns = {df.columns}")

    close = df["close"]

    # --- EMA ---
    df["ema_fast"] = EMAIndicator(close=close, window=9).ema_indicator()
    df["ema_slow"] = EMAIndicator(close=close, window=21).ema_indicator()
    
    # --- RSI ---
    df["rsi"] = RSIIndicator(close=close, window=14).rsi()

    # --- MACD ---
    macd = MACD(close=close)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_hist"] = macd.macd_diff()

    # --- RETURN ---
    df["return_1"] = close.pct_change()

    # --- CLEAN ---
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.bfill().ffill()

    return df
