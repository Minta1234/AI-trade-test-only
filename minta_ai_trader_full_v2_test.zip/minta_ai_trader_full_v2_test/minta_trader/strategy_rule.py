
import pandas as pd


class RuleStrategy:
    """
    กลยุทธ์พื้นฐานแบบ Rule-based:
    - ถ้า EMA เร็ว > EMA ช้า และ RSI < oversold -> BUY
    - ถ้า EMA เร็ว < EMA ช้า และ RSI > overbought -> SELL
    - อื่น ๆ -> HOLD
    """

    def __init__(self, rsi_overbought: float = 70.0, rsi_oversold: float = 30.0):
        self.rsi_overbought = rsi_overbought
        self.rsi_oversold = rsi_oversold

    def generate_signal(self, row: pd.Series) -> str:
        ema_fast = row["ema_fast"]
        ema_slow = row["ema_slow"]
        rsi = row["rsi"]

        if ema_fast > ema_slow and rsi < self.rsi_oversold:
            return "BUY"
        elif ema_fast < ema_slow and rsi > self.rsi_overbought:
            return "SELL"
        else:
            return "HOLD"
