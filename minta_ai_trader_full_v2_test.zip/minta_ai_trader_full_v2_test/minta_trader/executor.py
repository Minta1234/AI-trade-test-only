
import csv
import os
from datetime import datetime


class PaperExecutor:
    """
    Executor สำหรับเทรดจำลอง (paper trading)
    - บันทึกดีลลง logs/trades.csv
    """

    def __init__(self, base_dir: str, initial_balance: float = 1000.0):
        self.base_dir = base_dir
        self.balance = initial_balance
        self.position = None  # {"side": "LONG"/"SHORT", "entry": float, "size": float, "symbol": str}
        self.logs_dir = os.path.join(base_dir, "logs")
        os.makedirs(self.logs_dir, exist_ok=True)
        self.trades_file = os.path.join(self.logs_dir, "trades.csv")

        if not os.path.exists(self.trades_file):
            with open(self.trades_file, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["time", "symbol", "side", "entry", "exit", "size", "pnl", "balance_after"])

    def open_position(self, symbol: str, side: str, entry_price: float, size: float):
        if size <= 0:
            return
        if self.position is not None:
            return
        self.position = {
            "symbol": symbol,
            "side": side,
            "entry": entry_price,
            "size": size,
        }

    def close_position(self, exit_price: float):
        if self.position is None:
            return

        side = self.position["side"]
        entry = self.position["entry"]
        size = self.position["size"]
        symbol = self.position["symbol"]

        if side == "LONG":
            pnl = (exit_price - entry) * size
        else:
            pnl = (entry - exit_price) * size

        self.balance += pnl
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

        with open(self.trades_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([now, symbol, side, entry, exit_price, size, pnl, self.balance])

        self.position = None
        return pnl
