
import pandas as pd
import os
from .strategy_rule import RuleStrategy
from .strategy_ai import AIStrategy
from .risk import RiskManager


class Backtester:
    def __init__(
        self,
        df: pd.DataFrame,
        base_dir: str,
        mode: str = "rule",
        initial_balance: float = 1000.0,
        risk_per_trade: float = 0.01,
    ):
        self.df = df.copy()
        self.mode = mode
        self.initial_balance = initial_balance
        self.balance = initial_balance
        self.risk_manager = RiskManager(balance=self.balance, risk_per_trade=risk_per_trade)
        self.base_dir = base_dir

        if mode == "rule":
            self.strategy = RuleStrategy()
        elif mode == "ai":
            self.strategy = AIStrategy(base_dir=base_dir)
        else:
            raise ValueError("mode must be 'rule' or 'ai'")

        self.position = None  # {"side": "LONG"/"SHORT", "entry": float, "size": float}
        self.equity_curve = []

    def run(self):
        for idx, row in self.df.iterrows():
            price = row["close"]

            # ถ้ามี position อยู่แล้ว ให้เช็คสัญญาณปิด
            if self.position is not None:
                signal = self.strategy.generate_signal(row)
                if (
                    (self.position["side"] == "LONG" and signal == "SELL") or
                    (self.position["side"] == "SHORT" and signal == "BUY")
                ):
                    pnl = self._close_position(price)
                    self.balance += pnl
                    self.risk_manager.update_balance(self.balance)
                    self.position = None

            # ถ้าไม่มี position -> หา signal เข้าใหม่
            if self.position is None:
                signal = self.strategy.generate_signal(row)
                if signal == "BUY":
                    stop_loss = price * 0.995  # stop 0.5% ต่ำกว่าราคาเข้า (ตัวอย่าง)
                    size = self.risk_manager.position_size(price, stop_loss)
                    self._open_position("LONG", price, size)
                elif signal == "SELL":
                    stop_loss = price * 1.005  # stop 0.5% สูงกว่าราคาเข้า
                    size = self.risk_manager.position_size(price, stop_loss)
                    self._open_position("SHORT", price, size)

            self.equity_curve.append(self.balance)

        return {
            "mode": self.mode,
            "initial_balance": self.initial_balance,
            "final_balance": self.balance,
            "pnl": self.balance - self.initial_balance,
            "equity_curve": self.equity_curve,
        }

    def _open_position(self, side: str, entry_price: float, size: float):
        if size <= 0:
            return
        self.position = {
            "side": side,
            "entry": entry_price,
            "size": size,
        }

    def _close_position(self, exit_price: float) -> float:
        if self.position is None:
            return 0.0

        side = self.position["side"]
        entry = self.position["entry"]
        size = self.position["size"]

        if side == "LONG":
            pnl = (exit_price - entry) * size
        else:  # SHORT
            pnl = (entry - exit_price) * size

        return pnl
