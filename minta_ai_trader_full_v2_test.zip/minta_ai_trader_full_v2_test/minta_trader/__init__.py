# Minta AI Trader Forex package
