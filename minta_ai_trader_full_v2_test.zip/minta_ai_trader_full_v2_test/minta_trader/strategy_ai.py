
import pandas as pd
import numpy as np
import joblib
import os


class AIStrategy:
    """
    กลยุทธ์ที่ใช้โมเดล AI ทำนายทิศทางแท่งถัดไป
    - ใช้ features: return_1, ema_fast, ema_slow, rsi
    - โมเดล / scaler โหลดจากโฟลเดอร์ models/
    """

    def __init__(self, base_dir: str):
        model_path = os.path.join(base_dir, "models", "ai_model.pkl")
        scaler_path = os.path.join(base_dir, "models", "scaler.pkl")

        if not os.path.exists(model_path) or not os.path.exists(scaler_path):
            raise FileNotFoundError("AI model or scaler not found. Please run train_ai.py first.")

        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)

    def generate_signal(self, row: pd.Series) -> str:
        feats = np.array([[
            row["return_1"],
            row["ema_fast"],
            row["ema_slow"],
            row["rsi"],
        ]])
        feats_scaled = self.scaler.transform(feats)
        pred = self.model.predict(feats_scaled)[0]
        # 1 = ขึ้น -> BUY, 0 = ลง/ไม่ขึ้น -> SELL
        return "BUY" if pred == 1 else "SELL"
